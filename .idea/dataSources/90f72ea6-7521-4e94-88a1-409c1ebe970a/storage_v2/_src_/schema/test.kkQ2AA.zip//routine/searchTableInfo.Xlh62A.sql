CREATE PROCEDURE searchTableInfo(IN tableName VARCHAR(100), IN beginPoint INTEGER(10),
                                 IN endPoint  INTEGER(10))
  BEGIN
  DECLARE searchSql VARCHAR(100);
  set searchSql = CONCAT("select * from "
												,tableName
												," limit " 
												, beginPoint 
												, " , " 
												, endPoint);
  
   set @searchSql = searchSql;#注意很重要，将连成成的字符串赋值给一个变量（可以之前没有定义，但要以@开头）
   prepare stmt from @searchSql;  #预处理需要执行的动态SQL，其中stmt是一个变量
   EXECUTE stmt;      #执行SQL语句
   deallocate prepare stmt;     #释放掉预处理段
END;

