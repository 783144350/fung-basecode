CREATE PROCEDURE createTablePro(IN tableName VARCHAR(100), IN yearInfo INTEGER(10))
  BEGIN
  DECLARE isTest INTEGER; 
  DECLARE tableNameTemp VARCHAR(100);
  DECLARE createTableSql VARCHAR(500);
  
  SET isTest = "ABC11111111";
  SELECT isTest;
  select "111111111111111111111";
  set tableNameTemp = concat(tableName , yearInfo);
  #拼接sql
  set createTableSql = CONCAT("CREATE TABLE `",tableNameTemp,"` ("
						,"`id` bigint(20) NOT NULL,"
            ,"`name` varchar(32) DEFAULT NULL,"
            ,"`age` int(3) DEFAULT NULL,"
            ,"PRIMARY KEY (`id`)"
            ,") ENGINE=MyISAM DEFAULT CHARSET=utf8;");
   set @createTableSql = createTableSql;#注意很重要，将连成成的字符串赋值给一个变量（可以之前没有定义，但要以@开头）
   
   prepare stmt from @createTableSql;  #预处理需要执行的动态SQL，其中stmt是一个变量
   EXECUTE stmt;      #执行SQL语句
   deallocate prepare stmt;     #释放掉预处理段
END;

